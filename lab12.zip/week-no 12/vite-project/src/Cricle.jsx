import "./circle.css";
export const Circle = () => {
  return (
    <>
      <h3>I am identified as Triangle</h3>
      <div className="circle"></div>
    </>
  );
};
