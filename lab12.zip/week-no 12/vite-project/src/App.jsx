import React from "react";
import TodoList from "./TodoList"; // Update import statement to import TodoList component
import "./App.css"; // Import any additional stylesheets if needed
import OnlineFeed from "./OnlineFeed";
import Game from "./gameOfriends";

function App() {
  return (
    <div className="App">
      <Game />
    </div>
  );
}

export default App;
