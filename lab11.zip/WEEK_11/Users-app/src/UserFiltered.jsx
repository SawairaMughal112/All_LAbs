import React, { useState } from "react";

const UserFiltered = ({ Udata }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredUsers = Udata.filter((user) => {
    return (
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.address.street.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.address.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.address.zip.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div>
      <h2>User Data</h2>
      <input
        type="text"
        placeholder="Search users..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <hr />

      <ul>
        {filteredUsers.map((user) => (
          <li key={user.id}>
            <strong>Name:</strong> {user.name}
            <br />
            <strong>Email:</strong> {user.email}
            <br />
            <strong>Address:</strong> {user.address.street}, {user.address.city}
            , {user.address.zip}
            <br />
            <strong>Phone:</strong> {user.phone}
            <br />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserFiltered;
