import React from "react";
import Users from "./Users";
import OnlineFeed from "./OnlineFeed";
import Udata from "./Udata";
import UserDisplay from "./UsersDisplay";
import UserFiltered from "./UserFiltered";
import UserFetch from "./FetchUsers";
// import Game from "./Kamiyab";
import Kamyab from "./Kamiyab";

function App() {
  return (
    <div className="App">
      {/* <h1>USER DATA</h1> */}
      <OnlineFeed />
    </div>
  );
}

export default App;
