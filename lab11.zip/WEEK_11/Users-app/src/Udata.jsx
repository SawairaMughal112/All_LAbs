const Udata = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    address: {
      street: "123 Main St",
      city: "Anytown",
      zip: "12345",
    },
    phone: "123-456-7890",
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    address: {
      street: "456 Elm St",
      city: "Othertown",
      zip: "67890",
    },
    phone: "987-654-3210",
  },
  {
    id: 3,
    name: "Alice Johnson",
    email: "alice@example.com",
    address: {
      street: "789 Oak St",
      city: "Sometown",
      zip: "54321",
    },
    phone: "111-222-3333",
  },
  {
    id: 4,
    name: "Bob Brown",
    email: "bob@example.com",
    address: {
      street: "101 Pine St",
      city: "Anothertown",
      zip: "98765",
    },
    phone: "444-555-6666",
  },
  {
    id: 5,
    name: "Eve Taylor",
    email: "eve@example.com",
    address: {
      street: "1313 Mockingbird Ln",
      city: "Spookytown",
      zip: "66666",
    },
    phone: "777-888-9999",
  },
];

export default Udata;
