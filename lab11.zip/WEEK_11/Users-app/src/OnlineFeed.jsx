import React, { useState, useEffect } from "react";
import "./onlineFeed.css";
import { User } from "./User";

export default function OnlineFeed() {
  // State variables to store users and posts data
  const [users, setUsers] = useState([]);
  const [posts, setPosts] = useState([]);

  // Function to fetch users data from an API
  const fetchUsers = () => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((apiResult) => apiResult.json())
      .then((data) => {
        // Slice the data to get the first 3 users
        const newData = data.slice(0, 3);
        // Update the users state by merging the previous state with the new data
        setUsers((prev) => [...prev, ...newData]);
      });
  };

  // Function to fetch posts data from an API
const fetchPosts = () => {
  fetch("https://jsonplaceholder.typicode.com/posts?_limit=3") // Fetching only 3 posts
    .then((apiResult) => apiResult.json())
    .then((data) => {
      // Update the posts state by merging the previous state with the fetched data
      setPosts((prevPosts) => [...prevPosts, ...data]);
    });
};
// Empty dependency array ensures that useEffect runs only once when component mounts

  return (
    <div className="main-container">
      {/* Container for displaying users */}
      <div className="users-container">
        {/* Button to fetch more users */}
        <button onClick={fetchUsers}>Fetch Users</button>
        {/* Display the total number of users */}
        <span>{users.length}</span>
        {/* Display the list of users */}
        <div className="users">
          {/* Map through the users array and render User component for each user */}
          {users.map((userItem, index) => (
            <User
              key={index}
              email={userItem.email}
              username={userItem.username}
              address={userItem.address}
            />
          ))}
        </div>
      </div>
      {/* Container for displaying posts */}
      <div className="posts-container">
        {/* Button to fetch more posts */}
        <button onClick={fetchPosts}>Fetch Posts</button>
        {/* Display the list of posts */}
        <div className="posts">
          {/* Map through the posts array and render each post */}
          {posts.map((post) => (
            <div key={post.id}>
              <h3>{post.title}</h3>
              <p>{post.body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
