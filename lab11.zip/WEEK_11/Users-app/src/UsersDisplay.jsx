import React from "react";
import Udata from "./Udata";

const UserDisplay = ({ Udata }) => {
  return (
    <div>
      {/* <h2>User Data</h2> */}
      <ul>
        {Udata.map((user) => (
          <li key={user.id}>
            <strong>Name:</strong> {user.name}
            <br />
            <strong>Email:</strong> {user.email}
            <br />
            <strong>Address:</strong> {user.address.street}, {user.address.city}
            , {user.address.zip}
            <br />
            <strong>Phone:</strong> {user.phone}
            <br />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserDisplay;
