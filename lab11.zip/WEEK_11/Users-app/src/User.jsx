/* eslint-disable react/prop-types */
// props: way to receive data
export const User = ({
  // default props
  username = "Loki", // Default username if not provided
  email = "Email@gmail.com", // Default email if not provided
  address = { city: "Custom City", zipcode: "0011" }, // Default address object if not provided
  index, // Index of the user in the list (not used in this component)
}) => {
  return (
    <div class="user"> {/* Outer div for styling */}
      <img
        src={`https://api.dicebear.com/8.x/lorelei/svg?seed=${username}`} // Generates a random avatar image based on the username
        alt="user" // Alt text for the image
      />
      <div>{username}</div> {/* Display username */}
      <div>{email}</div> {/* Display email */}
      <div>
        Address :{" "} {/* Text for the address */}
        <span>
          {address?.city || "Custom City"}, ({address?.zipcode || "0011"}) {/* Display city and zipcode */}
        </span>
      </div>
    </div>
  );
};
